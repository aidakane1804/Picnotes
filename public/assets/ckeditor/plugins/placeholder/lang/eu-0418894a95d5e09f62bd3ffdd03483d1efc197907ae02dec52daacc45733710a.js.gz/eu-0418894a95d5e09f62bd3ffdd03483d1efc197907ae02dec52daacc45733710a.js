/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */


CKEDITOR.plugins.setLang( 'placeholder', 'eu', {
	title: 'Leku-marka propietateak',
	toolbar: 'Leku-marka',
	name: 'Leku-markaren izena',
	invalidName: 'Leku-markak ezin du hutsik egon eta ezin ditu karaktere hauek eduki: [, ], <, >',
	pathName: 'leku-marka'
} );
